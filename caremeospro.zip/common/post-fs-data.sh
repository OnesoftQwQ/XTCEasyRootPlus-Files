#!/data/adb/magisk/busybox sh
MODDIR=${0%/*}
data=$(getprop persist.sys.wipedata)
if [ "$data" = "0" ]; then   
FIND_FILE="/dev/block/bootdevice/by-name/misc"
FIND_STR="--wipe_data"
if [ `grep -c "$FIND_STR" $FIND_FILE` -ne '0' ];then
    mkfs.ext4 /dev/block/bootdevice/by-name/userdata&&reboot
fi
fi
recovery=$(getprop persist.sys.recovery)
rec=$(getprop persist.sys.rec)
if [ "$recovery" = "0" ]; then   
if [ "$rec" = "1" ]; then   
setprop persist.sys.rec 0
reboot recovery
fi
setprop persist.sys.recovery 1
id="$(echo "${0%/*}" | cut -d'/' -f5)"
for i in $(ls -d ${MODPATH%/*}/* )
do
    test "$id" = "${i##*/}" && continue
    touch "$i/disable"
    rm /data/adb/modules/XTCPatch/disable
    rm /data/adb/modules/XTC-CaremeOSPro/disable
    setprop persist.sys.rec 1
    reboot
done
fi