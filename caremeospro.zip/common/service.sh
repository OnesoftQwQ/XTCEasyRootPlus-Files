#!/data/adb/magisk/busybox sh
MODDIR=${0%/*}
battery=$(getprop persist.sys.watch.battery)
if [ "$battery" = "1" ]; then
pm enable com.xtc.weichat
pm enable com.xtc.moment
pm enable com.xtc.datacenter
pm enable com.xtc.xws
pm enable com.xtc.theme
pm enable com.xtc.i3launcher
pm disable-user com.xtc.oldi3launcher
fi
set -o standalone
(
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
sleep 5
done
setprop persist.sys.recovery 1
setprop persist.sys.rec 0
)&
data=$(getprop persist.sys.wadb)
if [ "$data" = "1" ]; then   
setprop persist.service.adb.enable 1
setprop persist.service.debuggable 1
setprop persist.adb.tcp.port 5555
setprop service.adb.tcp.port 5555
setprop ctl.restart adbd
fi
kugou="/data/media/0/Android/data/com.kugou.android.watch.lite/cache/"
if [ -d "$kugou" ]; then
rm -R /data/media/0/Android/data/com.kugou.android.watch.lite/cache/
fi
am force-stop com.xtc.theme
am force-stop com.qualcomm.qcrilmsgtunnel
am force-stop com.android.cellbroadcastreceiver
am force-stop com.qualcomm.qti.poweroffalarm
