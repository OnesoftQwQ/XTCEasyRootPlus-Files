SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
print_modname() {
FILE="$TMPDIR/word.txt"
if [[ ! -f "$FILE" ]]; then
    echo "文件 $FILE 不存在！"
    exit 1
fi
LINE_COUNT=$(wc -l < "$FILE")
RANDOM_LINE=$(( RANDOM % LINE_COUNT + 1 ))
SELECTED_POEM=$(sed -n "${RANDOM_LINE}p" "$FILE")
  ui_print "$SELECTED_POEM" 
  ui_print "  开始安装:CaremeOS Pro "
  ui_print "    Sky iMoo 保留所有权 "
  androidversion=$(getprop ro.build.version.release)
  ui_print "    手表安卓版本：$androidversion "
  model=$(getprop ro.product.model)
  ui_print "    手表型号：$model "
  innermodel=$(getprop ro.product.innermodel)
  ui_print "  手表innermodel：$innermodel "
  imoo_ver="`grep_prop ro.product.current.softversion`"
  ui_print "  手表真实版本：$imoo_ver "
}
on_install() {
mkdir /data/caremeospro-files > nul
echo 1 > /data/caremeospro-files/file
  data=$(getprop persist.sys.wadb)
if [ "$data" = "0" ]; then
  ui_print "- 您设置了不默认开启WIFI ADB"
  ui_print "- 不配置开启WIFI ADB"
else
  ui_print "- 您未设置不默认开启WIFI ADB"
  ui_print "- 您可能是首次安装"
  ui_print "- 默认配置开启WIFI ADB"
  setprop persist.sys.wadb 1
fi
for f in /data/adb/modules/*/module.prop; do
          sed -i '/^priority=/d' "$f"
done
settings=$(getprop persist.sys.settingversion)
if [ "$settings" = "Ver3" ]; then
  ui_print "- 您已经安装了手表设置Ultra-Ver3"
  ui_print "- 无需重复安装"
else
  ui_print "- 开始安装/更新手表设置 Ultra"
  curl -o $TMPDIR/settings.apk https://vip.123pan.cn/1814215835/xtc_root/settings.apk 
  pm install -r -t -d $TMPDIR/settings.apk
  setprop persist.sys.settingversion Ver3
fi
moment=$(getprop persist.sys.momentversion)
if [ "$moment" = "Ver5" ]; then
  ui_print "- 您已经安装了好友圈Ultra-Ver5"
  ui_print "- 无需重复安装"
else
  ui_print "- 开始安装/更新好友圈 Ultra"
  curl -o $TMPDIR/moment.apk https://vip.123pan.cn/1814215835/xtc_root/moment.apk
  pm install -r -t -d $TMPDIR/moment.apk
  setprop persist.sys.momentversion Ver5
fi
camera=$(getprop persist.sys.cameraversion)
if [ "$moment" = "116700" ]; then
  ui_print "- 您已经安装了相机Ultra 116700"
  ui_print "- 无需重复安装"
else
  ui_print "- 开始安装/更新修改版相机"
  curl -o $TMPDIR/camera.apk https://vip.123pan.cn/1814215835/xtc_root/camera.apk
  pm install -r -t -d $TMPDIR/camera.apk
  ui_print "- 正在进行对相机的额外配置"
  setprop persist.sys.cameraversion 11670
fi
module_path="/data/adb/modules/theme_ful"
if [ -d "$module_path" ]; then
  ui_print "- 模块 alltheme 已安装"
else
  ui_print "- 模块 alltheme 未安装，建议安装"
fi


dd if=/dev/block/bootdevice/by-name/misc of=$TMPDIR/misc.img
FIND_FILE="$TMPDIR/misc.img"
FIND_STR="boot-recovery"
if [ `grep -c "$FIND_STR" $FIND_FILE` -ne '0' ];then
ui_print "- 您使用的是Recovery方案ROOT！"
ui_print "- 不刷入TWRP"
else
twrp=$(getprop persist.sys.twrp)
  if [ "$twrp" = "1" ]; then
  ui_print "- 已刷入TWRP，无需重复刷入"
else
curl -o $TMPDIR/twrp.img https://vip.123pan.cn/1814215835/xtc_root/$(getprop ro.product.innermodel)_TWRP.img
twrp=$(cat twrp.img)
fail=$(cat fail.txt)
if [ "$twrp" = "$fail" ]; then
ui_print "- 暂不支持$innermodel刷入TWRP"
else
ui_print "- 即将刷入TWRP"
  dd if=$TMPDIR/twrp.img of=/dev/block/bootdevice/by-name/recovery
  ui_print "- 已尝试刷入"
  setprop persist.sys.twrp 1
fi
fi
fi
  ui_print "- 开始安装新UI运动"
  curl -o $TMPDIR/sport.apk https://storeshow-qn.okii.com/appstore/305616b52c794d22a8eca6a4e8fd9fe41728887374102
  pm install -r -t -d $TMPDIR/sport.apk 
PACKAGE_NAME=com.xtc.timemanager
# 检测应用是否已安装
isInstalled=$(pm list packages -s | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 应用 时间大师 已安装."
else
   ui_print "- 开始安装：时间大师"
    curl -o $TMPDIR/time.apk https://storeshow-qn.okii.com/watch-tmptest/file/2024/03/07/1506/28807/abce761a9fcd9a61f61cd5ad27ba2a5c
  pm install -r -t -d $TMPDIR/time.apk
    ui_print "- 应用 时间大师 安装完成." 
fi
PACKAGE_NAME=info.papdt.blackblub
# 检测应用是否已安装
isInstalled=$(pm list packages -s | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 应用 夜间屏幕 已安装."
else
   ui_print "- 开始安装：夜间屏幕"
  pm install -r -t -d $TMPDIR/NightMode.apk
   ui_print "- 应用 夜间屏幕 安装完成." 
fi
PACKAGE_NAME=com.example.ProcessManager
# 检测应用是否已安装
isInstalled=$(pm list packages -s | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 应用 进程管理器 已安装."
else
   ui_print "- 开始安装：进程管理器"
  pm install -r -t -d $TMPDIR/NightMode.apk
   ui_print "- 应用 进程管理器 安装完成." 
fi
PACKAGE_NAME=com.xtc.intelligentIdentify
# 检测应用是否已安装
isInstalled=$(pm list packages -s | grep ${PACKAGE_NAME})
if [ -n "$isInstalled" ]; then
    ui_print "- 卸载系统应用：$PACKAGE_NAME"
    pm uninstall --user 0 ${PACKAGE_NAME}
    ui_print "- 系统应用 $PACKAGE_NAME 卸载完成."
else
    ui_print "- 系统应用 $PACKAGE_NAME 未安装."
fi
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  model=$(getprop ro.product.innermodel)
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  ui_print "年少时抬头仰望夜空，看到的尽是梦想"
  ui_print "Welcome to CaremeOSPro!"
}