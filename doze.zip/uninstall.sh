#!/sbin/sh
file="
/data/media/0/Android/doze.log
/data/media/0/Android/doze.conf
"

for i in $file ;do
test -e "$i" && rm -rf $i
done