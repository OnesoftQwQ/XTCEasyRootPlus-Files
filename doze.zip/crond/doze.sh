#!/system/bin/sh

BUSYBOXDIR=$MODPATH/busybox
export PATH=/system/bin:$BUSYBOXDIR:$PATH
export TZ=Asia/Shanghai

dozefile=/data/media/0/Android/doze.conf

function limitlog(){
	local logfile=$1
	local maxsize=$((1024*10))
	filesize=`ls -l $logfile | awk '{ print $5 }'`
	if test "$filesize" -gt "$maxsize" ;then
		echo " " > $logfile
	fi
}

function Log() {
	txt="/data/media/0/Android/doze.log"
	echo -e "$(date '+%y年%m月%d日%T') 电量: "$(dumpsys battery | awk '/level/{print $2}')" "$1" \n" >> $txt
	limitlog "$txt"
}


function app (){
	cat $dozefile | sed '/^[[:space:]]*$/d;/^#/d;s/+//g;/whitelist.*\"/d;s/\"//g'
}


function MAKE_RESET_WHITE(){
	#清理白名单
	for i in `dumpsys deviceidle whitelist | cut -d ',' -f 2 | sed '/com.tencent.mm/d;/com.tencent.mobileqq/d '`;do
		dumpsys deviceidle whitelist -$i
	done
	#加入白名单
	for i in $(app);do dumpsys deviceidle whitelist +$i ;done
}


function clear_white_list (){
	if test -f "$dozefile" ; then
		MAKE_RESET_WHITE
		check=$?
		if test "$check" = "0" ; then
			Log "清理电池优化名单成功!"
		else
			Log "清理电池优化名单失败!"
		fi
	else
		Log "未找到doze.conf，Doze白名单优化未执行，请到APP生成白名单或者自行创建白名单。"
	fi
}

#识别屏幕状态
screen=`dumpsys deviceidle get screen`

function GET_DEEP_SLEEP(){
	dumpsys deviceidle | grep -q Enabled=true && echo "true" || echo "false"
}


if test "$screen" = "false" ; then
	sleep 10s
	if test "$(GET_DEEP_SLEEP)" = "false" ; then
		#执行移出电池优化名单
		clear_white_list
		#level 1 dumpsys deviceidle enable
		#level 2 dumpsys deviceidle enable deep
		#默认开启level 3
		dumpsys deviceidle enable deep
		dumpsys deviceidle force-idle deep
		#修改记得注释掉
		Log "😴熄灭屏幕进入深度 Doze😴"
		#日志
		Log "是否亮屏: $screen, 当前休眠状态：$(dumpsys deviceidle get deep) ,是否强制休眠: $(dumpsys deviceidle get force)"
	fi
else
	if test "$(GET_DEEP_SLEEP)" = "true" ; then
		dumpsys deviceidle disable all
		dumpsys deviceidle unforce
		Log "🥱点亮屏幕退出深度 Doze🥱"
		#日志
		Log "是否亮屏: $screen, 当前休眠状态：$(dumpsys deviceidle get deep) ,是否强制休眠: $(dumpsys deviceidle get force)"
	fi
fi


