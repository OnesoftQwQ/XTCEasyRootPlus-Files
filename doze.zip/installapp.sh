appfile=`find $MODPATH -name "*.apk" | head -n 1`
appexist=`pm list package -a | grep -w 'com.github.hwwwwwlemon.dozeconfig' | wc -l`

echo ""
echo "∞————————————————————————∞"
echo ""
echo "－ 安装应用中……"
if test "$appexist" -ge 1 ;then
	echo "- 已安装应用，跳过安装！"
else
	pm install -r -d "$appfile" > /dev/null 2>&1
	test $? == 0 && echo "－ 安装成功！" || echo "- 安装失败！"
fi
echo "－ 配置电池白名单中……"
targetfile=/data/media/0/Android/doze.conf
test ! -e $targetfile && {
	cp -rf $MODPATH/1doze.conf $targetfile
} || echo "－ 已存在电池白名单文件！跳过覆盖安装！"
echo ""
echo "∞————————————————————————∞"