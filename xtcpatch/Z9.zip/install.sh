SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
print_modname() {
  ui_print "==================="
  ui_print "- 永远相信美好的事情即将发生"
  ui_print "-  Installing XTCPatch "
  ui_print "-  By Sky iMoo "
  ui_print "==================="
  ui_print "******************************"
  ui_print "=     免责申明     ="
  ui_print "1.所有已经解除第三方软件安装限制的手表都可以恢复到解除限制前之状态。"
  ui_print "2.解除第三方软件安装限制后，您的手表可以无限制地安装第三方软件，需要家长加强对孩子的监管力度，避免孩子沉迷网络，影响学习；手表自带的功能不受影响。"
  ui_print "3.您对手表进行解除第三方软件安装限制之操作属于您的自愿行为，若在操作过程中由于操作不当等自身原因，导致出现手表无法正常使用等异常情况，以及解除软件安装限制之后产生的一切后果将由您本人承担！"
  ui_print "4.如果您使用本工具包与模块对手表进行解除第三方软件安装限制之操作，即默认您同意本《免责声明》。"
  ui_print "******************************"
  ui_print "=   5s后开始安装   ="
  sleep 5
  ui_print "=    开始安装      ="
}
on_install() {
  ui_print "- 正在释放文件"
  module_path="/data/adb/modules/XTCModule"
# 检查模块是否存在
if [ -d "$module_path" ]; then
  ui_print "- 准备卸载模块 XTCModule..."
  
  # 卸载模块
  su -c "rm -R /data/adb/modules/XTCModule"
  
  ui_print "- 模块 XTCModule 已卸载。"
else
  ui_print "- 模块 XTCModule 不存在，无需卸载。"
fi
  module_path="/data/adb/modules/XTC-Patch"
# 检查模块是否存在
if [ -d "$module_path" ]; then
  su -c "rm -R /data/adb/modules/XTC-Patch"
fi
  setprop persist.xtcpatch.version 10022
  pm clear com.android.packageinstaller
  pm install -r -t -d $TMPDIR/file.apk
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}