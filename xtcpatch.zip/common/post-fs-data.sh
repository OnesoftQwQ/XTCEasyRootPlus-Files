#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread
MODEL=$(getprop "ro.product.innermodel")
androidversion=$(getprop ro.build.version.release)
if test "$androidversion" = "8.1.0"; then
if test "$MODEL" = "I20"; then
    resetprop ro.product.current.softversion 2.7.0
    resetprop ro.product.jenkins.number 2098
    resetprop ro.build.date.utc 1729827644
    resetprop ro.build.date "Fri Oct 25 11:40:44 CST 2024"
    resetprop ro.product.codebranch origin/I20/V2.7.0
    resetprop ro.product.commit 2a1cefc4
fi

if test "$MODEL" = "I25"; then
    resetprop ro.product.current.softversion 2.4.5
    resetprop ro.product.jenkins.number 2077
    resetprop ro.build.date.utc 1729827698
    resetprop ro.build.date Fri Oct 25 11:41:38 CST 2024
    resetprop ro.product.codebranch "origin/I25/V2.4.5"
    resetprop ro.product.commit 670714fa
fi

if test "$MODEL" = "I25C"; then
    resetprop ro.product.current.softversion 1.8.1
    resetprop ro.product.jenkins.number 2024
    resetprop ro.build.date.utc 1729844503
    resetprop ro.build.date "Fri Oct 25 16:21:43 CST 2024"
    resetprop ro.product.codebranch origin/I25C/V1.8.1
    resetprop ro.product.commit 2d9b31ee
fi

if test "$MODEL" = "I25D"; then
    resetprop ro.product.current.softversion 1.5.8
    resetprop ro.product.jenkins.number 612
    resetprop ro.build.date.utc 1729501118
    resetprop ro.build.date "Mon Oct 21 16:58:38 CST 2024"
    resetprop ro.product.codebranch origin/I25D/V1.5.8
    resetprop ro.product.commit 3f1121ee
fi

if test "$MODEL" = "I32"; then
    resetprop ro.product.current.softversion 3.0.6
    resetprop ro.product.jenkins.number 2094
    resetprop ro.build.date.utc 1729574576
    resetprop ro.build.date "Tue Oct 22 13:22:56 CST 2024"
    resetprop ro.product.codebranch origin/I32/V3.0.6
    resetprop ro.product.commit fa0ef9c2
fi

if test "$MODEL" = "ND01"; then
    resetprop ro.product.current.softversion 3.3.7
    resetprop ro.product.jenkins.number 1020
    resetprop ro.build.date.utc 1732589976
    resetprop ro.build.date "Tue Nov 26 10:59:36 CST 2024"
    resetprop ro.product.codebranch origin/ND01/V3.3.7
    resetprop ro.product.commit a9fcf4fd
fi

if test "$MODEL" = "ND07"; then
    resetprop ro.product.current.softversion 1.5.1
    resetprop ro.build.date.utc 1732869241
    resetprop ro.build.date "Fri Nov 29 16:34:01 CST 2024"
    resetprop ro.product.codebranch origin/ND07/V1.5.0
    resetprop ro.product.jenkins.number 252
fi
else
resetprop ro.product.current.softversion 5.0.0
fi
resetprop ro.build.type userdebug